# robocopy-gui

**robocopy-gui** is a modern Windows GUI for Microsoft Robocopy.

It helps you copy, move, mirror, synchronize and back up folders without writing command-line commands manually.

## Features

- Modern dark Windows interface
- Copy, Move, Mirror and Dry Run modes
- Source and destination folder picker
- Queue system for multiple transfer jobs
- Job profiles saved as JSON
- Backup presets
- Turkish and English language support
- Robocopy command preview
- Multithread support with `/MT`
- Retry and wait options with `/R` and `/W`
- Exclude files and folders with `/XF` and `/XD`
- Live Robocopy output log
- Transfer history export
- Save logs automatically
- Open destination folder
- Safe warning for `/MIR`
- Portable release support
- GitHub Actions build workflow
- Single-file EXE publishing

## Warning

The `/MIR` option mirrors the source folder to the destination folder.  
It can delete destination files that do not exist in the source folder.

## Build

Install .NET 8 SDK, then run:

```bat
build-release.bat
```

Output:

```txt
release\RoboCopyGui.exe
```

## Development

```bat
run-dev.bat
```

## Release

GitHub Actions builds the Windows EXE automatically when you push a tag like:

```txt
v2.0.0
```

## License

MIT
