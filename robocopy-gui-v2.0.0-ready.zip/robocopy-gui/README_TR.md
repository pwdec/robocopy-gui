# robocopy-gui

**robocopy-gui**, Microsoft Robocopy komutunu modern bir Windows arayüzüne dönüştüren açık kaynak bir araçtır.

Komut satırı yazmadan klasör kopyalama, taşıma, aynalama, senkronizasyon ve yedekleme işlemleri yapmanı sağlar.

## Özellikler

- Modern koyu Windows arayüzü
- Copy, Move, Mirror ve Dry Run modları
- Kaynak ve hedef klasör seçici
- Birden fazla işi sıraya alma sistemi
- JSON olarak profil kaydetme
- Hazır yedekleme presetleri
- Türkçe ve İngilizce dil desteği
- Robocopy komut önizleme
- `/MT` ile çoklu thread desteği
- `/R` ve `/W` ile tekrar/bekleme ayarı
- `/XF` ve `/XD` ile dosya/klasör hariç tutma
- Canlı Robocopy log ekranı
- İşlem geçmişi dışa aktarma
- Logları otomatik kaydetme
- Hedef klasörü açma
- `/MIR` için güvenlik uyarısı
- Portable release desteği
- GitHub Actions build workflow
- Tek dosya EXE üretimi

## Uyarı

`/MIR` seçeneği hedef klasörü kaynak klasöre göre aynalar.  
Kaynakta olmayan dosyalar hedef klasörden silinebilir.

## Derleme

.NET 8 SDK kurulu olmalı:

```bat
build-release.bat
```

Çıktı:

```txt
release\RoboCopyGui.exe
```

## Lisans

MIT
