using System.Text.Json;

namespace RoboCopyGui;

public static class Storage
{
    private static readonly JsonSerializerOptions Options = new()
    {
        WriteIndented = true
    };

    public static string AppFolder
    {
        get
        {
            var p = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "robocopy-gui");
            Directory.CreateDirectory(p);
            Directory.CreateDirectory(Path.Combine(p, "profiles"));
            Directory.CreateDirectory(Path.Combine(p, "logs"));
            Directory.CreateDirectory(Path.Combine(p, "history"));
            return p;
        }
    }

    public static string LogsFolder => Directory.CreateDirectory(Path.Combine(AppFolder, "logs")).FullName;
    public static string HistoryFolder => Directory.CreateDirectory(Path.Combine(AppFolder, "history")).FullName;
    public static string ProfilesFolder => Directory.CreateDirectory(Path.Combine(AppFolder, "profiles")).FullName;

    public static void SaveProfile(TransferJob job, string path)
    {
        File.WriteAllText(path, JsonSerializer.Serialize(job, Options));
    }

    public static TransferJob LoadProfile(string path)
    {
        return JsonSerializer.Deserialize<TransferJob>(File.ReadAllText(path), Options) ?? new TransferJob();
    }

    public static void AppendHistory(string line)
    {
        var path = Path.Combine(HistoryFolder, $"history-{DateTime.Now:yyyyMMdd}.csv");
        if (!File.Exists(path))
            File.WriteAllText(path, "date,name,mode,source,destination\n");

        File.AppendAllText(path, line + Environment.NewLine);
    }
}
