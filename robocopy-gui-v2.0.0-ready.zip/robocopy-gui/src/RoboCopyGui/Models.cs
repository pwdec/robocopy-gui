using System.Text.Json.Serialization;

namespace RoboCopyGui;

public enum TransferMode
{
    Copy,
    Move,
    Mirror
}

public sealed class TransferJob
{
    public string Name { get; set; } = "New Job";
    public string Source { get; set; } = "";
    public string Destination { get; set; } = "";
    public TransferMode Mode { get; set; } = TransferMode.Copy;
    public bool IncludeSubfolders { get; set; } = true;
    public bool DryRun { get; set; }
    public bool SaveLog { get; set; } = true;
    public int Threads { get; set; } = 32;
    public int Retries { get; set; } = 1;
    public int WaitSeconds { get; set; } = 1;
    public string ExcludeFiles { get; set; } = "";
    public string ExcludeFolders { get; set; } = "";
}

public sealed class AppSettings
{
    public string Language { get; set; } = "tr";
    public string Theme { get; set; } = "Dark";
    public List<string> RecentSources { get; set; } = new();
    public List<string> RecentDestinations { get; set; } = new();
}
