using System.Diagnostics;
using System.Text.Json;

namespace RoboCopyGui;

public sealed class MainForm : Form
{
    private readonly Color Bg = Color.FromArgb(15, 17, 23);
    private readonly Color Panel = Color.FromArgb(25, 29, 40);
    private readonly Color Panel2 = Color.FromArgb(35, 40, 55);
    private readonly Color TextC = Color.FromArgb(235, 239, 245);
    private readonly Color Muted = Color.FromArgb(148, 163, 184);
    private readonly Color Accent = Color.FromArgb(59, 130, 246);
    private readonly Color Green = Color.FromArgb(34, 197, 94);
    private readonly Color Red = Color.FromArgb(239, 68, 68);

    private string languageCode = "tr";
    private Language L => new(languageCode);

    private Process? process;
    private readonly Queue<TransferJob> queue = new();

    private TextBox source = new();
    private TextBox dest = new();
    private TextBox excludeFiles = new();
    private TextBox excludeFolders = new();
    private TextBox command = new();
    private TextBox log = new();
    private TextBox jobName = new();

    private ComboBox lang = new();
    private ComboBox mode = new();
    private NumericUpDown threads = new();
    private NumericUpDown retries = new();
    private NumericUpDown wait = new();

    private CheckBox include = new();
    private CheckBox dryRun = new();
    private CheckBox saveLog = new();

    private ListBox queueList = new();

    private readonly List<Control> translatable = new();

    public MainForm()
    {
        Text = "robocopy-gui";
        Width = 1240;
        Height = 820;
        MinimumSize = new Size(1100, 720);
        StartPosition = FormStartPosition.CenterScreen;
        BackColor = Bg;
        Font = new Font("Segoe UI", 10);

        Build();
        ApplyLanguage();
        UpdatePreview();
    }

    private void Build()
    {
        var title = Label("robocopy-gui", 26, true);
        title.SetBounds(24, 18, 340, 42);
        Controls.Add(title);

        var sub = Label("Modern Windows GUI for Robocopy", 10, false, Muted);
        sub.SetBounds(28, 58, 450, 24);
        Controls.Add(sub);

        lang = Combo();
        lang.Items.AddRange(new object[] { "Türkçe", "English" });
        lang.SelectedIndex = 0;
        lang.SetBounds(1020, 26, 170, 32);
        lang.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        lang.SelectedIndexChanged += (_, _) => { languageCode = lang.SelectedIndex == 1 ? "en" : "tr"; ApplyLanguage(); };
        Controls.Add(lang);

        var left = Card(24, 100, 550, 315);
        Controls.Add(left);

        var right = Card(596, 100, 600, 315);
        Controls.Add(right);

        AddInput(left, "Source", source, 20, 28, true);
        AddInput(left, "Destination", dest, 20, 102, true);

        AddLabel(left, "Mode", 20, 178);
        mode = Combo();
        mode.Items.AddRange(new object[] { "Copy", "Move", "Mirror" });
        mode.SelectedIndex = 0;
        mode.SetBounds(20, 205, 160, 34);
        mode.SelectedIndexChanged += (_, _) => UpdatePreview();
        left.Controls.Add(mode);

        jobName = Box();
        jobName.PlaceholderText = "Job name";
        jobName.Text = "New Job";
        jobName.SetBounds(200, 205, 230, 34);
        jobName.TextChanged += (_, _) => UpdatePreview();
        left.Controls.Add(jobName);

        var openBtn = Btn("OpenDest", Accent);
        openBtn.SetBounds(445, 205, 84, 34);
        openBtn.Click += (_, _) => OpenDestination();
        left.Controls.Add(openBtn);

        include = Check("Include");
        include.Checked = true;
        include.SetBounds(20, 258, 170, 28);
        include.CheckedChanged += (_, _) => UpdatePreview();
        left.Controls.Add(include);

        dryRun = Check("DryRun");
        dryRun.SetBounds(200, 258, 170, 28);
        dryRun.CheckedChanged += (_, _) => UpdatePreview();
        left.Controls.Add(dryRun);

        saveLog = Check("SaveLog");
        saveLog.Checked = true;
        saveLog.SetBounds(380, 258, 140, 28);
        saveLog.CheckedChanged += (_, _) => UpdatePreview();
        left.Controls.Add(saveLog);

        AddNumber(right, "Threads", threads, 20, 28, 1, 128, 32);
        AddNumber(right, "Retries", retries, 215, 28, 0, 100, 1);
        AddNumber(right, "Wait", wait, 410, 28, 0, 300, 1);

        AddLabel(right, "ExcludeFiles", 20, 105);
        excludeFiles = Box();
        excludeFiles.PlaceholderText = "*.tmp; *.bak";
        excludeFiles.SetBounds(20, 132, 250, 34);
        excludeFiles.TextChanged += (_, _) => UpdatePreview();
        right.Controls.Add(excludeFiles);

        AddLabel(right, "ExcludeFolders", 310, 105);
        excludeFolders = Box();
        excludeFolders.PlaceholderText = "node_modules; bin; obj";
        excludeFolders.SetBounds(310, 132, 250, 34);
        excludeFolders.TextChanged += (_, _) => UpdatePreview();
        right.Controls.Add(excludeFolders);

        AddLabel(right, "Command", 20, 190);
        command = Box();
        command.ReadOnly = true;
        command.SetBounds(20, 217, 540, 34);
        right.Controls.Add(command);

        var addQueue = Btn("AddQueue", Accent);
        addQueue.SetBounds(20, 265, 130, 36);
        addQueue.Click += (_, _) => AddToQueue();
        right.Controls.Add(addQueue);

        var saveProfile = Btn("SaveProfile", Green);
        saveProfile.SetBounds(165, 265, 130, 36);
        saveProfile.Click += (_, _) => SaveProfile();
        right.Controls.Add(saveProfile);

        var loadProfile = Btn("LoadProfile", Accent);
        loadProfile.SetBounds(310, 265, 130, 36);
        loadProfile.Click += (_, _) => LoadProfile();
        right.Controls.Add(loadProfile);

        var mid = Card(24, 435, 360, 305);
        Controls.Add(mid);

        AddLabel(mid, "Queue", 20, 16);
        queueList = new ListBox
        {
            BackColor = Color.FromArgb(10, 12, 18),
            ForeColor = TextC,
            BorderStyle = BorderStyle.FixedSingle,
            Font = new Font("Segoe UI", 9)
        };
        queueList.SetBounds(20, 48, 315, 160);
        mid.Controls.Add(queueList);

        var start = Btn("Start", Green);
        start.SetBounds(20, 224, 95, 42);
        start.Click += async (_, _) => await StartSingle();
        mid.Controls.Add(start);

        var runQueue = Btn("RunQueue", Accent);
        runQueue.SetBounds(125, 224, 105, 42);
        runQueue.Click += async (_, _) => await RunQueue();
        mid.Controls.Add(runQueue);

        var stop = Btn("Stop", Red);
        stop.SetBounds(240, 224, 95, 42);
        stop.Click += (_, _) => StopProcess();
        mid.Controls.Add(stop);

        var logCard = Card(405, 435, 791, 305);
        Controls.Add(logCard);

        AddLabel(logCard, "Log", 20, 16);

        var clear = Btn("Clear", Accent);
        clear.SetBounds(650, 14, 105, 30);
        clear.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        clear.Click += (_, _) => log.Clear();
        logCard.Controls.Add(clear);

        log = new TextBox
        {
            BackColor = Color.FromArgb(10, 12, 18),
            ForeColor = Color.FromArgb(209, 213, 219),
            BorderStyle = BorderStyle.FixedSingle,
            Font = new Font("Consolas", 9),
            Multiline = true,
            ScrollBars = ScrollBars.Vertical,
            ReadOnly = true
        };
        log.SetBounds(20, 52, 735, 225);
        log.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
        logCard.Controls.Add(log);
    }

    private Panel Card(int x, int y, int w, int h)
    {
        return new Panel
        {
            BackColor = Panel,
            Left = x,
            Top = y,
            Width = w,
            Height = h,
            Anchor = AnchorStyles.Top | AnchorStyles.Left
        };
    }

    private Label Label(string text, int size, bool bold, Color? c = null)
    {
        return new Label
        {
            Text = text,
            ForeColor = c ?? TextC,
            BackColor = Color.Transparent,
            Font = new Font("Segoe UI", size, bold ? FontStyle.Bold : FontStyle.Regular),
            AutoSize = false
        };
    }

    private void AddLabel(Control parent, string key, int x, int y)
    {
        var l = Label(key, 10, true);
        l.Name = "lbl_" + key;
        l.Tag = key;
        l.SetBounds(x, y, 220, 24);
        translatable.Add(l);
        parent.Controls.Add(l);
    }

    private void AddInput(Control parent, string key, TextBox box, int x, int y, bool browse)
    {
        AddLabel(parent, key, x, y);
        box.BackColor = Panel2;
        box.ForeColor = TextC;
        box.BorderStyle = BorderStyle.FixedSingle;
        box.SetBounds(x, y + 28, 390, 34);
        box.TextChanged += (_, _) => UpdatePreview();
        parent.Controls.Add(box);

        if (browse)
        {
            var b = Btn("Browse", Accent);
            b.SetBounds(x + 405, y + 28, 85, 34);
            b.Click += (_, _) => PickFolder(box);
            parent.Controls.Add(b);
        }
    }

    private void AddNumber(Control parent, string key, NumericUpDown n, int x, int y, int min, int max, int val)
    {
        AddLabel(parent, key, x, y);
        n.Minimum = min;
        n.Maximum = max;
        n.Value = val;
        n.BackColor = Panel2;
        n.ForeColor = TextC;
        n.SetBounds(x, y + 28, 145, 34);
        n.ValueChanged += (_, _) => UpdatePreview();
        parent.Controls.Add(n);
    }

    private TextBox Box() => new()
    {
        BackColor = Panel2,
        ForeColor = TextC,
        BorderStyle = BorderStyle.FixedSingle
    };

    private ComboBox Combo() => new()
    {
        DropDownStyle = ComboBoxStyle.DropDownList,
        BackColor = Panel2,
        ForeColor = TextC,
        FlatStyle = FlatStyle.Flat
    };

    private CheckBox Check(string key)
    {
        var c = new CheckBox
        {
            Tag = key,
            Text = key,
            ForeColor = TextC,
            BackColor = Color.Transparent,
            AutoSize = false
        };
        translatable.Add(c);
        return c;
    }

    private Button Btn(string key, Color color)
    {
        var b = new Button
        {
            Tag = key,
            Text = key,
            BackColor = color,
            ForeColor = Color.White,
            FlatStyle = FlatStyle.Flat,
            Cursor = Cursors.Hand,
            Font = new Font("Segoe UI", 9, FontStyle.Bold)
        };
        b.FlatAppearance.BorderSize = 0;
        translatable.Add(b);
        return b;
    }

    private void ApplyLanguage()
    {
        Text = L["Title"];
        foreach (var c in translatable)
        {
            if (c.Tag is string key)
                c.Text = L[key];
        }
    }

    private TransferJob GetJob()
    {
        return new TransferJob
        {
            Name = string.IsNullOrWhiteSpace(jobName.Text) ? "New Job" : jobName.Text.Trim(),
            Source = source.Text,
            Destination = dest.Text,
            Mode = mode.SelectedIndex switch
            {
                1 => TransferMode.Move,
                2 => TransferMode.Mirror,
                _ => TransferMode.Copy
            },
            IncludeSubfolders = include.Checked,
            DryRun = dryRun.Checked,
            SaveLog = saveLog.Checked,
            Threads = (int)threads.Value,
            Retries = (int)retries.Value,
            WaitSeconds = (int)wait.Value,
            ExcludeFiles = excludeFiles.Text,
            ExcludeFolders = excludeFolders.Text
        };
    }

    private void SetJob(TransferJob j)
    {
        jobName.Text = j.Name;
        source.Text = j.Source;
        dest.Text = j.Destination;
        mode.SelectedIndex = j.Mode == TransferMode.Move ? 1 : j.Mode == TransferMode.Mirror ? 2 : 0;
        include.Checked = j.IncludeSubfolders;
        dryRun.Checked = j.DryRun;
        saveLog.Checked = j.SaveLog;
        threads.Value = Math.Clamp(j.Threads, (int)threads.Minimum, (int)threads.Maximum);
        retries.Value = Math.Clamp(j.Retries, (int)retries.Minimum, (int)retries.Maximum);
        wait.Value = Math.Clamp(j.WaitSeconds, (int)wait.Minimum, (int)wait.Maximum);
        excludeFiles.Text = j.ExcludeFiles;
        excludeFolders.Text = j.ExcludeFolders;
        UpdatePreview();
    }

    private void UpdatePreview()
    {
        command.Text = RoboCopyCommandBuilder.BuildPreview(GetJob());
    }

    private void PickFolder(TextBox target)
    {
        using var f = new FolderBrowserDialog { ShowNewFolderButton = true };
        if (f.ShowDialog(this) == DialogResult.OK)
            target.Text = f.SelectedPath;
    }

    private void AddToQueue()
    {
        var j = GetJob();
        if (!ValidateJob(j)) return;
        queue.Enqueue(j);
        queueList.Items.Add($"{j.Name} [{j.Mode}]");
        Append($"Queued: {j.Name}");
    }

    private async Task StartSingle()
    {
        var j = GetJob();
        if (!ValidateJob(j)) return;
        await RunJob(j);
    }

    private async Task RunQueue()
    {
        while (queue.Count > 0)
        {
            var j = queue.Dequeue();
            if (queueList.Items.Count > 0) queueList.Items.RemoveAt(0);
            await RunJob(j);
        }
    }

    private bool ValidateJob(TransferJob j)
    {
        if (string.IsNullOrWhiteSpace(j.Source) || string.IsNullOrWhiteSpace(j.Destination))
        {
            MessageBox.Show(L["Missing"], L["Title"], MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return false;
        }

        if (j.Mode == TransferMode.Mirror)
        {
            var r = MessageBox.Show(L["MirrorWarn"], L["Title"], MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            return r == DialogResult.Yes;
        }

        return true;
    }

    private async Task RunJob(TransferJob j)
    {
        string? logPath = null;
        if (j.SaveLog)
            logPath = Path.Combine(Storage.LogsFolder, $"robocopy-{DateTime.Now:yyyyMMdd-HHmmss}.log");

        var args = RoboCopyCommandBuilder.BuildArguments(j, logPath);
        Append("> robocopy " + args);

        try
        {
            process = new Process();
            process.StartInfo.FileName = "robocopy";
            process.StartInfo.Arguments = args;
            process.StartInfo.UseShellExecute = false;
            process.StartInfo.RedirectStandardOutput = true;
            process.StartInfo.RedirectStandardError = true;
            process.StartInfo.CreateNoWindow = true;

            process.OutputDataReceived += (_, e) => Append(e.Data);
            process.ErrorDataReceived += (_, e) => Append(e.Data);

            process.Start();
            process.BeginOutputReadLine();
            process.BeginErrorReadLine();

            await process.WaitForExitAsync();

            Storage.AppendHistory($"{DateTime.Now:O},{Csv(j.Name)},{j.Mode},{Csv(j.Source)},{Csv(j.Destination)}");
            Append($"{L["Done"]} ExitCode={process.ExitCode}");
        }
        catch (Exception ex)
        {
            Append("ERROR: " + ex.Message);
        }
        finally
        {
            process?.Dispose();
            process = null;
        }
    }

    private void StopProcess()
    {
        try
        {
            if (process is { HasExited: false })
            {
                process.Kill(true);
                Append(L["Cancelled"]);
            }
        }
        catch { }
    }

    private void SaveProfile()
    {
        using var s = new SaveFileDialog
        {
            Filter = "RoboCopy GUI Profile (*.json)|*.json",
            FileName = "profile.json"
        };
        if (s.ShowDialog(this) == DialogResult.OK)
        {
            Storage.SaveProfile(GetJob(), s.FileName);
            Append(L["ProfileSaved"]);
        }
    }

    private void LoadProfile()
    {
        using var o = new OpenFileDialog
        {
            Filter = "RoboCopy GUI Profile (*.json)|*.json"
        };
        if (o.ShowDialog(this) == DialogResult.OK)
        {
            SetJob(Storage.LoadProfile(o.FileName));
            Append(L["ProfileLoaded"]);
        }
    }

    private void OpenDestination()
    {
        if (Directory.Exists(dest.Text))
            Process.Start(new ProcessStartInfo(dest.Text) { UseShellExecute = true });
    }

    private void Append(string? line)
    {
        if (string.IsNullOrWhiteSpace(line)) return;
        if (InvokeRequired)
        {
            BeginInvoke(() => Append(line));
            return;
        }
        log.AppendText($"[{DateTime.Now:HH:mm:ss}] {line}{Environment.NewLine}");
    }

    private static string Csv(string s) => "\"" + s.Replace("\"", "\"\"") + "\"";
}
