namespace RoboCopyGui;

public sealed class Language
{
    private readonly string _code;

    public Language(string code)
    {
        _code = code;
    }

    public string this[string key] => Get(key);

    private string Get(string key)
    {
        Dictionary<string, string> tr = new()
        {
            ["Title"] = "robocopy-gui",
            ["Subtitle"] = "Robocopy için modern Windows arayüzü",
            ["Source"] = "Kaynak",
            ["Destination"] = "Hedef",
            ["Browse"] = "Seç",
            ["Mode"] = "Mod",
            ["Copy"] = "Kopyala",
            ["Move"] = "Taşı",
            ["Mirror"] = "Aynala",
            ["DryRun"] = "Sadece önizleme /L",
            ["Include"] = "Alt klasörler /E",
            ["SaveLog"] = "Log kaydet",
            ["Threads"] = "Thread /MT",
            ["Retries"] = "Tekrar /R",
            ["Wait"] = "Bekleme /W",
            ["ExcludeFiles"] = "Hariç dosyalar",
            ["ExcludeFolders"] = "Hariç klasörler",
            ["Command"] = "Komut önizleme",
            ["Queue"] = "Kuyruk",
            ["AddQueue"] = "Kuyruğa ekle",
            ["RunQueue"] = "Kuyruğu başlat",
            ["Start"] = "Başlat",
            ["Stop"] = "Durdur",
            ["SaveProfile"] = "Profil kaydet",
            ["LoadProfile"] = "Profil yükle",
            ["ExportHistory"] = "Geçmiş dışa aktar",
            ["OpenDest"] = "Hedefi aç",
            ["Clear"] = "Temizle",
            ["Log"] = "Canlı log",
            ["Missing"] = "Kaynak ve hedef klasör seçmelisin.",
            ["MirrorWarn"] = "Aynalama modu hedefteki fazla dosyaları silebilir. Devam edilsin mi?",
            ["Done"] = "İşlem tamamlandı.",
            ["Cancelled"] = "İşlem durduruldu.",
            ["ProfileSaved"] = "Profil kaydedildi.",
            ["ProfileLoaded"] = "Profil yüklendi.",
        };

        Dictionary<string, string> en = new()
        {
            ["Title"] = "robocopy-gui",
            ["Subtitle"] = "Modern Windows GUI for Robocopy",
            ["Source"] = "Source",
            ["Destination"] = "Destination",
            ["Browse"] = "Browse",
            ["Mode"] = "Mode",
            ["Copy"] = "Copy",
            ["Move"] = "Move",
            ["Mirror"] = "Mirror",
            ["DryRun"] = "Preview only /L",
            ["Include"] = "Subfolders /E",
            ["SaveLog"] = "Save log",
            ["Threads"] = "Threads /MT",
            ["Retries"] = "Retries /R",
            ["Wait"] = "Wait /W",
            ["ExcludeFiles"] = "Exclude files",
            ["ExcludeFolders"] = "Exclude folders",
            ["Command"] = "Command preview",
            ["Queue"] = "Queue",
            ["AddQueue"] = "Add to queue",
            ["RunQueue"] = "Run queue",
            ["Start"] = "Start",
            ["Stop"] = "Stop",
            ["SaveProfile"] = "Save profile",
            ["LoadProfile"] = "Load profile",
            ["ExportHistory"] = "Export history",
            ["OpenDest"] = "Open destination",
            ["Clear"] = "Clear",
            ["Log"] = "Live log",
            ["Missing"] = "Please select source and destination folders.",
            ["MirrorWarn"] = "Mirror mode can delete extra files in the destination. Continue?",
            ["Done"] = "Operation completed.",
            ["Cancelled"] = "Operation stopped.",
            ["ProfileSaved"] = "Profile saved.",
            ["ProfileLoaded"] = "Profile loaded.",
        };

        var d = _code == "en" ? en : tr;
        return d.TryGetValue(key, out var value) ? value : key;
    }
}
