using System.Text;

namespace RoboCopyGui;

public static class RoboCopyCommandBuilder
{
    public static string BuildArguments(TransferJob job, string? logPath = null)
    {
        var sb = new StringBuilder();

        sb.Append(Q(job.Source)).Append(' ');
        sb.Append(Q(job.Destination)).Append(' ');

        if (job.Mode == TransferMode.Mirror)
            sb.Append("/MIR ");
        else if (job.IncludeSubfolders)
            sb.Append("/E ");

        if (job.Mode == TransferMode.Move)
            sb.Append("/MOVE ");

        if (job.DryRun)
            sb.Append("/L ");

        sb.Append($"/MT:{job.Threads} ");
        sb.Append($"/R:{job.Retries} ");
        sb.Append($"/W:{job.WaitSeconds} ");
        sb.Append("/TEE /NP ");

        AddList(sb, "/XF", job.ExcludeFiles);
        AddList(sb, "/XD", job.ExcludeFolders);

        if (!string.IsNullOrWhiteSpace(logPath))
            sb.Append("/LOG:").Append(Q(logPath)).Append(' ');

        return sb.ToString().Trim();
    }

    public static string BuildPreview(TransferJob job)
    {
        return "robocopy " + BuildArguments(job, job.SaveLog ? "logs\\robocopy-date.log" : null);
    }

    private static void AddList(StringBuilder sb, string option, string value)
    {
        if (string.IsNullOrWhiteSpace(value))
            return;

        var items = value.Split(new[] { ',', ';' }, StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        if (items.Length == 0) return;

        sb.Append(option).Append(' ');
        foreach (var item in items)
            sb.Append(Q(item)).Append(' ');
    }

    private static string Q(string value) => "\"" + value.Trim().Trim('"') + "\"";
}
