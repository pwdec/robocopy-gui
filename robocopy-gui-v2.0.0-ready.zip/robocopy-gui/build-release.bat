@echo off
setlocal
cd /d "%~dp0"

echo Building robocopy-gui release...
dotnet publish src\RoboCopyGui\RoboCopyGui.csproj -c Release -r win-x64 --self-contained true ^
  /p:PublishSingleFile=true ^
  /p:IncludeNativeLibrariesForSelfExtract=true ^
  /p:EnableCompressionInSingleFile=true ^
  /p:PublishReadyToRun=true ^
  -o release

echo.
echo Done.
echo Output: release\RoboCopyGui.exe
pause
