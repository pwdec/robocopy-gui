# robocopy-gui v2.0.0

Initial advanced release.

## Added

- Copy / Move / Mirror modes
- Queue manager
- Profile save/load
- Backup presets
- TR/EN language switch
- Live log output
- Command preview
- Exclude files and folders
- Thread/retry/wait controls
- Auto log saving
- History export
- GitHub Actions Windows build
- Single-file EXE publish script
