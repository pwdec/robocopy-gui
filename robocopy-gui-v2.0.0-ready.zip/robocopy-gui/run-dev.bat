@echo off
dotnet run --project src\RoboCopyGui\RoboCopyGui.csproj
pause
